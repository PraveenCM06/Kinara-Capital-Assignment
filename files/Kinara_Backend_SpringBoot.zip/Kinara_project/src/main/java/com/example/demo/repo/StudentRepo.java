package com.example.demo.repo;

//import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;

//import java.awt.print.Pageable;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.module.Student;

public interface StudentRepo extends JpaRepository<Student, Integer> {
	Page<Student> findAll(Pageable pageable);
}
