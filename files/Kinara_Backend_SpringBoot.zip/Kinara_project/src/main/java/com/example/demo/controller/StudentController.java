package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.module.Student;
import com.example.demo.repo.StudentRepo;
import com.example.demo.service.StudentService;
@CrossOrigin(origins="http://localhost:3001")
@RestController
public class StudentController {
	
	@Autowired
	StudentService studentservice;
	
	@Autowired
	StudentRepo repo;
	
	@PostMapping("/addstudent")
	public ResponseEntity<Student> addStudent(@RequestBody Student s){
		return new ResponseEntity<Student>(studentservice.addStudent(s), HttpStatus.CREATED);
	}
	
	@GetMapping("/getstudents")
	List<Student> getAllStudents(){
		return studentservice.getAllStudents();
	}
	
	@GetMapping("/api/students")
	//http://localhost:8080/api/students?page=1&size=5
	 public ResponseEntity<Page<Student>> getStudents(Pageable pageable){
		 Page<Student> students = repo.findAll(pageable);
	        return ResponseEntity.ok(students);
	 }
}
