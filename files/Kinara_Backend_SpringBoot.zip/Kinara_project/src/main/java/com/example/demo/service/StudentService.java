package com.example.demo.service;

import java.util.List;

import com.example.demo.module.Student;

public interface StudentService {
	Student addStudent(Student s);
	
	List<Student> getAllStudents();
}
